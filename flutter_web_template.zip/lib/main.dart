
import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'New Home App',
      home: Scaffold(
        appBar: AppBar(title: Text('New Home - Adopción')),
        body: Center(
          child: Text(
            '¡Bienvenido a New Home!',
            style: TextStyle(fontSize: 24),
          ),
        ),
      ),
    );
  }
}
